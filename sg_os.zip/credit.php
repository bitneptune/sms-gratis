		<!--Dilarang menghapus ataupun mengubah apapun pada bagian ini-->

		<div class="container">
			<br>
			<p class="text-center text-light">Script by <a class="text-light" href="https://github.com/bitneptune/sms-gratis/" target="_blank"><strong><u>Free SMS Script</u></strong></a>, SMS API by <a class="text-light" href="<?php echo "$api_url"; ?>" target="_blank"><strong><u>KuySMS.me</u></strong></a> and Theme by <a class="text-light" href="https://colorlib.com/" target="_blank"><strong><u>Colorlib</u></strong></a></p>
		</div>
		
		<!--Dilarang menghapus ataupun mengubah apapun pada bagian ini-->
		