<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'fs_os';

$source_url = 'https://bitneptune.com';
$api_url = 'https://kuysms.me';

$conn = mysqli_connect($hostname, $username, $password, $database);